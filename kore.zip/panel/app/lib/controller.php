<?php

class Controller extends Obj {

}