<div class="modal-content modal-content-large">
  <?php echo $form ?>
</div>