<div class="modal-content" data-action="<?php echo $page->isVisible() ? 'unpublish' : 'publish' ?>">
  <?php echo $form ?>
</div>