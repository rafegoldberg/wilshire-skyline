/**
 *
 */
var DashboardController = {

  index : function() {
    app.main.view('dashboard/index');
  }

};