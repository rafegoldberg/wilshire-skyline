title:
  label: pages.add.title.label
  type: title
  placeholder: pages.add.title.placeholder
  autocomplete: false
  autofocus: true
  required: true
uid:
  label: pages.add.url.label
  type: text
  icon: chain
  autocomplete: false
  required: true
