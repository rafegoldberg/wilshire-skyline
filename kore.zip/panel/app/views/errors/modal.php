<div class="modal-content">

  <div class="form">
    <div class="field">
      <label class="label"><?php _l('error.headline') ?></label>
      <p><?php __($message) ?></p>
    </div>
    <div class="buttons buttons-centered cf">
      <a class="btn btn-rounded btn-cancel" href="#"><?php _l('ok') ?></a>
    </div>
  </div>

</div>